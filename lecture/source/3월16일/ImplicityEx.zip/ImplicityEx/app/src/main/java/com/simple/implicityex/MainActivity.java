package com.simple.implicityex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("LifeCycle","onCreate() 호출됨");
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.i("LifeCycle","onStart() 호출됨");
    }

    public void onResume(){
        super.onResume();
        Log.i("LifeCycle","onResume() 호출됨");
    }

    public void onPause(){
        super.onPause();
        Log.i("LifeCycle","onPause() 호출됨");
    }

    public void onStop(){
        super.onStop();
        Log.i("LifeCycle","onStop() 호출됨");
    }

    public void onDestroy(){
        super.onDestroy();
        Log.i("LifeCycle","onDestroy() 호출됨");
    }


    public void onClick(View view){
        Intent intent = null;
        if(view.getId() == R.id.web){
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.naver.com"));
        } else if (view.getId() == R.id.call) {
            intent = new Intent(Intent.ACTION_DIAL,Uri.parse("tel:(+82)04212344567"));
        }else if (view.getId() == R.id.map) {
            intent = new Intent(Intent.ACTION_VIEW,Uri.parse("geo:38.30,127.2?z=4"));
        }else if (view.getId() == R.id.contact)  {
            intent = new Intent(Intent.ACTION_VIEW,Uri.parse("content://contacts/people/"));
        }

        if(intent != null){
            startActivity(intent);
        }

    }
}