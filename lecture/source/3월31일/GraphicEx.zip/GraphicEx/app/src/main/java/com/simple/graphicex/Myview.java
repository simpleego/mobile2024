package com.simple.graphicex;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.jar.Attributes;

public class Myview  extends View {
    public Myview(Context context) {
        super(context);
        setBackgroundColor(Color.BLUE);
    }

    public Myview(Context context, AttributeSet attrs) {
        super(context);
        setBackgroundColor(Color.BLUE);
    }

    protected void onDraw(Canvas canvas){
        // 도화지는 준비되었고, 붓과 물감이 필요하다.

        // 붓과 물감을 준비
        Paint paint = new Paint();

        // 그림 색상 선정
        paint.setColor(Color.YELLOW);
        paint.setStrokeWidth(20);
        canvas.drawLine(100,100,700,100,paint);
        canvas.drawLine(100,100,100,700,paint);
        canvas.drawLine(100,700,700,700,paint);
        canvas.drawLine(700,100,700,700,paint);

        // 사각형 그리기(빨강색으로)
        paint.setColor(Color.RED);
        paint.setStrokeWidth(30);

        canvas.drawRect(200,200,900,900,paint);

        paint.setColor(Color.WHITE);
        paint.setStrokeWidth(20);
        canvas.drawCircle(300,300,300,paint);

        // 그래픽 글자 출력
        paint.setTextSize(10);
        canvas.drawText("안녕하세요 글자를 보여준다.",100,1200,paint);


    }
}
