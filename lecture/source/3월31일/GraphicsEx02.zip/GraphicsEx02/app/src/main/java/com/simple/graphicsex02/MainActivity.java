package com.simple.graphicsex02;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CustomView view = new CustomView(this);
        setContentView(view);
    }
}

class CustomView extends View {
    // 그리기에 필요한 도구 준비
    private List<Circle> circles = new ArrayList<>();
    private Paint paint;


    public CustomView(Context context) {
        super(context);
        paint = new Paint();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Toast.makeText(getContext(),"test",Toast.LENGTH_SHORT).show();
        for(Circle circle : circles){
            paint.setColor(circle.color);
            canvas.drawCircle(circle.x, circle.y,circle.radius, paint);
        }
    }
    @Override
    public boolean onTouchEvent(MotionEvent event){
        // 임의의 반지름 설정
        if(event.getAction() == MotionEvent.ACTION_DOWN) {

            Random random = new Random();
            float radius = random.nextInt(300);

            // 임의의 컬러 설정
            int color = Color.rgb(
                    random.nextInt(256),
                    random.nextInt(256),
                    random.nextInt(256)
                    );


            float x = event.getX();
            float y = event.getY();

            Circle circle = new Circle(x, y, radius, color);
            circles.add(circle);
            //onDraw();
            invalidate();// 화면이 현재 다시 그려야 될 상황이면 다시 그려라(onDraw())
            return true;
        }
        return super.onTouchEvent(event);
    }

    private class Circle{
        float x, y, radius;
        int color;

        Circle(float x, float y, float radius, int color){
            this.x = x;
            this.y = y;
            this.radius = radius;
            this.color = color;
        }
    }


}

