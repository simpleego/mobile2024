package com.simple.contextmenuex;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = findViewById(R.id.text1);
        registerForContextMenu(text);
    }

    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, v, menuInfo);

        menu.setHeaderTitle("컨텍스트 메뉴");
        menu.add(0,1,0,"배경색: RED");
        menu.add(0,2,0,"배경색: GREEN");
        menu.add(0,3,0,"배경색: BLUE");
    }

    public boolean onContextItemSelected(MenuItem item){
        int id = item.getItemId();
        if(id == 1){
            text.setBackgroundColor(Color.RED);
            return true;
        }
        if(id == 2){
            text.setBackgroundColor(Color.GREEN);
            return true;
        }
        if(id == 3){
            text.setBackgroundColor(Color.BLUE);
            return true;
        }

        return true;
        //return super.onContextItemSelected(item);

    }

    public void onClick(View view){
        PopupMenu popupMenu = new PopupMenu(this,view);
        popupMenu.getMenuInflater().inflate(R.menu.popup, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(
                new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        Toast.makeText(getApplicationContext(),
                                "클릭된 팝업 메뉴 "+item.getTitle(),
                                Toast.LENGTH_LONG).show();
                        return true;
                    }
                }
        );
        popupMenu.show();
    }




}