package com.simple.networkex01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText display;
    Button get;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        get = (Button) findViewById(R.id.get);
        display = (EditText) findViewById(R.id.display);

        get.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo activeNet = manager.getActiveNetworkInfo();
                    if (activeNet != null) {
                        if (activeNet.getType() == ConnectivityManager.TYPE_WIFI) {
                            display.setText(activeNet.toString());
                        } else if (activeNet.getType() == ConnectivityManager.TYPE_MOBILE) {
                            display.setText(activeNet.toString());
                        }
                    }
                } catch (Exception e) {
                }
            }
        });
    }
}