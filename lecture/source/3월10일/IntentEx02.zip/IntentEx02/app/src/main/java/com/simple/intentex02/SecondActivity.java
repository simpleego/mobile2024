package com.simple.intentex02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    // 아이디와 비번을 확인 후 결과를 반환
    private TextView displayIDTextView, displayPasswoedTextView, statusTextView;
    String id, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);

        displayIDTextView =  findViewById(R.id.displayIdTextView);
        displayPasswoedTextView = findViewById(R.id.displayPasswordTextView);
        statusTextView = findViewById(R.id.loginSuccess);

        // 인텐트 저장소에 저장된 값을 꺼내기
        Intent intent = getIntent();
        if(intent != null){
            id = intent.getStringExtra("ID");
            password = intent.getStringExtra("password");

            displayIDTextView.setText("아이디 : "+id);
            displayPasswoedTextView.setText("비번 : "+password);
        }
    }

    public void check(View view){
        // 로그인 로직 (더미 데이터 사용)

        Intent intent = new Intent();
        if(isUserVaild(id,password)) {
            // 인증 성공
            intent.putExtra("status","로그인 성공");
        }else {
            // 인증 실패
            intent.putExtra("status","로그인 실패");
        }
        setResult(RESULT_OK,intent);
        finish();
    }

    private boolean isUserVaild(String username, String password) {

        boolean result = username.equals("kim") && password.equals("1234");

        return result; //username.equals("kim") && password.equals("1234");
    }


}