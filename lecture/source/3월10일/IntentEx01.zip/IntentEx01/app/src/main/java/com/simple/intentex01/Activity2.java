package com.simple.intentex01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout2);

        Button btn1 = findViewById(R.id.Button02);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 버튼 기능을 수행
                // 다음 화면을 호출 : 명시적 인텐트를 이용해서 호출
                Intent intent = new Intent(Activity2.this, Activity3.class);
                startActivity(intent);
            }
        });


        Button btn = findViewById(R.id.Button01);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 닫기 기능을 수행
              finish();
            }
        });
    }
}