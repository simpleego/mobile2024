package com.simple.listviewex;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 데이터 배열 생성
        String[] data = {"Apple", "Apricot", "Avocado", "Banana", "Blackberry",
                "Blueberry", "Cherry", "Coconut", "Cranberry",
                "Grape Raisin", "Honeydew", "Jackfruit", "Lemon", "Lime",
                "Mango", "Watermelon"};

        // 어댑터가 배열을 입력으로 받아서 리스트뷰에 맞게 출력
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, data);

        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(adapter);

        // List 항목에 대한 처리 이벤트
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = data[position];
                Toast.makeText(getApplicationContext(), "선택한 항목" + selectedItem,
                        Toast.LENGTH_LONG).show();
            }
        });

    }
}